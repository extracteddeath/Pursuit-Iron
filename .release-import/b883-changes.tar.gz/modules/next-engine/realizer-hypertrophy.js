// M230 canonical hypertrophy stage. Stage context is local to one realization.
import { desiredDirect, integerSetPlan } from './realizer-math.js';
import { LARGE, SMALL, muscleCandidate } from './realizer-ranking.js';
import { NOVICE_FULL_BODY_PATTERN_EXPOSURES } from './config.js';

export function realizeMajorMuscles(context) {
const { add, exerciseCatalog, ledger, plans, request, sessions, targetDose, weeklyMovementUse } = context;
/* M230:PRESERVE:stage.realizeMajorMuscles:BEGIN */
for (const muscle of LARGE) {
        const allEntries = sessions.flatMap(s => s.plan.allocations
            .filter(a => a.kind === 'muscle' && a.muscle === muscle)
            .map(allocation => ({ session: s, allocation })));
        if (!allEntries.length)
            continue;
        const fullBodyCapacityContract = plans.every(p => p.intent === 'full') && (plans.some(p => p.targetExercises !== undefined) || request.preferences.lockedSplit === 'full_body');
        const mandatoryFullBodyMuscle = fullBodyCapacityContract && ['chest', 'back'].includes(muscle);
        const directlyCovers = s => s.defs.some(def => (def.muscles[muscle]?.credit ?? 0) >= 1);
        const uncoveredEntries = allEntries.filter(entry => !directlyCovers(entry.session));
        // A novice's squat/hinge frequency on full body is an EXPOSURE count, not a set count. A day whose
        // strength anchor already trains the muscle directly counts as one; each missing exposure gets a
        // real 2-set block on a distinct uncovered day. Two sets, not one: a one-set accessory is exactly
        // what the fragment passes consolidate away, which silently turns the exposure back into none.
        const novicePatternTarget = fullBodyCapacityContract && request.athlete.experience === 'novice'
            ? Math.min(sessions.length, NOVICE_FULL_BODY_PATTERN_EXPOSURES[muscle] ?? 0) : 0;
        const novicePatternEntries = novicePatternTarget
            ? uncoveredEntries.filter((entry, i, list) => list.findIndex(e => e.session === entry.session) === i)
                .slice(0, Math.max(0, novicePatternTarget - sessions.filter(directlyCovers).length))
            : [];
        const entries = mandatoryFullBodyMuscle ? uncoveredEntries : novicePatternEntries.length ? novicePatternEntries : allEntries;
        const activeEntries = entries.length ? entries : allEntries;
        const modeledTarget = targetDose[muscle] ?? allEntries.reduce((sum, e) => sum + e.allocation.dose, 0);
        const perUncoveredSession = request.athlete.experience === 'novice' ? 1 : 2;
        const current = ledger.fractional[muscle] ?? 0;
        const target = mandatoryFullBodyMuscle
            ? Math.max(modeledTarget, current + perUncoveredSession * activeEntries.length)
            : novicePatternEntries.length
                ? Math.max(modeledTarget, current + 2 * novicePatternEntries.length)
                : modeledTarget;
        const residual = Math.max(0, Math.round(target - current));
        if (residual <= 0)
            continue;
        const setPlan = integerSetPlan(activeEntries, residual);
        for (const entry of activeEntries) {
            const sets = setPlan.get(entry) ?? 0;
            if (sets <= 0)
                continue;
            const def = muscleCandidate(entry.allocation, entry.session.plan, request, entry.session.defs, weeklyMovementUse, exerciseCatalog);
            if (!def)
                continue;
            add(entry.session, entry.allocation, def, sets);
        }
    }
/* M230:PRESERVE:stage.realizeMajorMuscles:END */

}

export function realizeDirectIsolations(context) {
const { add, directTargetDose, exerciseCatalog, ledger, request, sessions, smallIntentPreference, targetDose, weeklyMovementUse } = context;
/* M230:PRESERVE:stage.realizeDirectIsolations:BEGIN */
for (const muscle of SMALL) {
        if (muscle === 'front_delts' && request.goal.musclePriorities.front_delts === 'normal')
            continue;
        const rankedSessions = [...sessions].sort((a, b) => {
            // Topology may deliberately spill a low-interference accessory onto a Lower/Leg day to balance
            // session density. Honor that explicit destination before the generic intent preference; otherwise
            // earlier Upper allocations can satisfy the global direct-volume target and silently erase the move.
            const aSpill = a.plan.allocations.some(x => x.kind === 'muscle' && x.muscle === muscle && x.id.includes('-spill-')) ? 1 : 0;
            const bSpill = b.plan.allocations.some(x => x.kind === 'muscle' && x.muscle === muscle && x.id.includes('-spill-')) ? 1 : 0;
            if (aSpill !== bSpill)
                return bSpill - aSpill;
            const pref = smallIntentPreference[muscle] ?? [];
            const ai = pref.indexOf(a.plan.intent);
            const bi = pref.indexOf(b.plan.intent);
            return (ai < 0 ? 99 : ai) - (bi < 0 ? 99 : bi);
        });
        for (const s of rankedSessions)
            for (const a of s.plan.allocations.filter(x => x.kind === 'muscle' && x.muscle === muscle)) {
                const target = targetDose[muscle] ?? a.dose;
                const totalResidual = Math.max(0, target - (ledger.fractional[muscle] ?? 0));
                const directResidual = Math.max(0, desiredDirect(muscle, target, directTargetDose) - (ledger.direct[muscle] ?? 0));
                const need = Math.max(totalResidual, directResidual);
                if (need < .75)
                    continue;
                const def = muscleCandidate(a, s.plan, request, s.defs, weeklyMovementUse, exerciseCatalog);
                if (!def)
                    continue;
                const sets = Math.max(1, Math.min(4, Math.round(Math.min(a.dose, need))));
                add(s, a, def, sets);
            }
    }
/* M230:PRESERVE:stage.realizeDirectIsolations:END */

}
